# MERN STACK EXERCISE APP FRONTEND

## TOOLS USED
- ReactJS
- Bootstrap
- React Router v6 ( npm i react-router-dom@next )
- React-DatePicker
- Axios

