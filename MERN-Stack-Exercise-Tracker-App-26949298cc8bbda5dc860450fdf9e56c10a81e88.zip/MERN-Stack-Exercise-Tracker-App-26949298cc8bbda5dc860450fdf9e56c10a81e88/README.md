# MERN-Stack-Exercise-Tracker-App

## Tools Used 
- MongoDB
- ExpressJs
- React
- NodeJs

### This repo contains complete Backend and FrontEnd code with documentaition 
this app is made using React Functional Components and React Hooks
- React UseState()
- React UseEffect()

# MERN STACK Exercise App Backend

## Tools Used
- Express ( NodeJs Server)
- Nodemon
- Mongoose
- MongoDB Atlas


# MERN STACK EXERCISE APP FRONTEND

## TOOLS USED
- ReactJS
- Bootstrap
- React Router v6 ( npm i react-router-dom@next )
- React-DatePicker
- Axios
