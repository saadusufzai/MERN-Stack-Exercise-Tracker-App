# MERN STACK Exercise App Backend

## Tools Used
- Express ( NodeJs Server)
- Nodemon
- Mongoose
- MongoDB Atlas
